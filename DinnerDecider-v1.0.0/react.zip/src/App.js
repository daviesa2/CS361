import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';

/* Function that defines the REACT app */
function App() {
  /* The return that defines the contents of the app */
  return (
    <div className="App">
      <Router>
        <div className="App-header">
          <Route path="/" exact>
            <HomePage />
          </Route>
          </div>
      </Router>
    </div>
  );
}

export default App;