import React, { Component } from 'react';
import { useState, useEffect } from 'react';
import { useHistory } from "react-router-dom";
import raw from '../results.txt'

/*export const FileRead = ({ outputToEdit }) => {
    const [output, setOutput] = useState(outputToEdit.output);
    const history = useHistory();
    fetch(raw)
        console.log(raw)
        .then(r => r.text())
        .then(text => setOutput(text));
    
};*/

function FileRead() {
    const vals = '';
    fetch(raw)
        console.log(raw)
        .then(r => r.text())
        .then(text => {const vals = text});
    return vals
}

export default FileRead