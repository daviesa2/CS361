import { GoogleMap, withScriptjs, withGoogleMap } from "react-google-maps";

function Map() {
    return <GoogleMap 
        defaultZoom={10}
        defaultCente={{lat: 47.6062, lng: 122.3321}}
    />;
}

const WrappedMap = withScriptjs(withGoogleMap(Map));