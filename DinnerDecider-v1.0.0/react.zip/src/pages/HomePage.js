import React from 'react';
import { useState } from 'react';
import { useHistory } from 'react-router-dom';
import {GiFoodTruck} from 'react-icons/gi';
import { GoogleMap, useJsApiLoader } from "@react-google-maps/api";

/* Function defining the home page of the app. Handed the parameter setExerciseToEdit */
function HomePage() {

    /* State variables and functions */
    const history = useHistory();
    const [location, setLocation] = useState('');
    const [price, setPrice] = useState('');
    const [rating, setRating] = useState('');
    const [range, setRange] = useState('');
    const [zoom, setZoom] = useState(12);
    const [center, setCenter] = useState({lat: 47.608013, lng: -122.335167})

    /* Async that uses POST to data to the database (interacts with services) */
    const addFilter = async () => {
        // Create the filters and the response/body
        const newFilter = { location, price, rating, range };
        const response = await fetch('/filters', {
            method: 'POST',
            body: JSON.stringify(newFilter),
            headers: {
                'Content-Type': 'application/json',
            },
        });
        // If the response is positive, await the JSON output and update the results/location
        if(response.status === 201){
            const newOutput = await response.json()
            updateOutput(newOutput.result)
            setCenter({lat: newOutput.lat, lng: newOutput.lng})
            setZoom(17)
        // Else, not that the request failed
        } else {
            alert(`Failed to submit. Status code = ${response.status}`);
        }
        history.push("/");
    };

    /* Async to update the output field */
    const updateOutput = async (text) => {
        document.getElementById("output").innerHTML = text
    }

    /* Define Google Map loading method */
    const libraries = [];
    const { isLoaded, loadError } = useJsApiLoader({
        googleMapsApiKey: process.env.REACT_APP_GOOGLE_API_KEY,
        libraries
    }); 

    /* Define Google Maps container size */
    const mapContainerStyle = {
        width: '50vw',
        height: '50vh'
    };
    if (loadError) return "Error loading Maps";
    if (!isLoaded) return "Loading Maps";

    /* Return the homepage; header, main, and footer present */
    return (
        <>
            <header className='header'>
                <h1>Dinner Decider</h1>
                <p><GiFoodTruck size={42}/></p>
                <p>For the "would you just pick" nights</p>
            </header>
            <main className='homepagebody'>
                <div class="row">
                    <div class="column">
                        <table id="add-exercise" className="table-wrapper">
                            <thead>
                                <tr>
                                    <th>Filters</th>
                                </tr>
                            </thead>
                            <tbody>
                                <fieldset>
                                <tr>
                                    <td>
                                        Location
                                    </td>
                                    <td>
                                        <input
                                        type="text"
                                        placeholder='Location'
                                        onChange={e => setLocation(e.target.value)} />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Price
                                    </td>
                                    <td>
                                        <select onChange={e => setPrice(e.target.value)}>
                                        <option value="">Any</option>
                                        <option value="$">$</option>
                                        <option value="$$">$$</option>
                                        <option value="$$$">$$$</option>
                                        <option value="$$$$">$$$$</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Rating
                                    </td>
                                    <td>
                                        <select onChange={e => setRating(e.target.value)}>
                                        <option value="">Any</option>
                                        <option value="2.0">2 stars</option>
                                        <option value="2.5">2.5 stars</option>
                                        <option value="3.0">3 stars</option>
                                        <option value="3.5">3.5 stars</option>
                                        <option value="4.0">4 stars</option>
                                        <option value="4.5">4.5 stars</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        Range
                                    </td>
                                    <td>
                                        <select onChange={e => setRange(e.target.value)}>
                                        <option value="" disabled selected>Any</option>
                                        <option value="2.5">2.5 miles</option>
                                        <option value="5">5 miles</option>
                                        <option value="10">10 miles</option>
                                        <option value="20">20 miles</option>
                                        </select>
                                    </td>
                                </tr>
                                </fieldset>
                            </tbody>
                        </table>
                        <button onClick={addFilter}>
                            Submit
                        </button>
                        <p id="output">So, what's for dinner?</p>
                    </div>
                    <div class="column">
                        <GoogleMap 
                            mapContainerStyle={mapContainerStyle} 
                            zoom={zoom} 
                            center={center}
                        />
                    </div>
                </div>
            </main>
            <footer className="footer">
                <p>Modified by Alex Davies (daviesa2) - &copy; 2022.</p>
            </footer>
        </>
    );
}

export default HomePage;