# Course: CS361 - Software I
# Student Name: Alex Davies
# Assignment: Final project - microservice
# Description: This microservice, when running, will look into a specified text file and return a random set from it.
# Date: 5/1/22 (v1.1.0)

import random
import time
import json
from os.path import exists
from copy import deepcopy

def compare_JSONs(file_a, file_b):
    """
    Takes two Map JSON outputs and returns an indicator of whether or not they are equals
    :param file_a: json
    :param file_b: json
    :return: Boolean - true if matching, false if not
    """
    # Set equal flag to true (return unless we find a false instance)
    equal = True
    # If the two file inputs are not the same type, then they aren't matches
    if type(file_a) != type(file_b):
        equal = False
    else:
        # If output is a key in both, lengths are equal, and have the same address, then its a match.
        # Else, they aren't a match (return false)
        if "output" in file_a and "output" in file_b:
            arr_a = file_a["output"]
            arr_b = file_b["output"]
            if len(arr_a) == len(arr_b):
                for index in range(len(arr_a)):
                    obj_a = arr_a[index]
                    obj_b = arr_b[index]
                    if obj_a["formatted_address"] != obj_b["formatted_address"]:
                        equal = False
            else:
                equal = False
        else:
            equal = False
    return equal

def filter_results(set):
    """
    Takes a set (list) of restaurants and returns a subset that fits the filter values
    :param set: (list)
    :return: subset (list)
    """
    # Open the filter file and collect the filter values
    filter_file = "additional_filters.txt"
    file = open(filter_file, 'r')
    filters = file.readline().split(', ')
    file.close()
    # Set the price filter based on whether one is provided or not.
    if filters[0] == '':
        filter_price = '$$$$'
    else:
        filter_price = filters[0]
    # Set the rating filter based on whether one is provided or not.
    if filters[1] == '':
        filter_rating = 0
    else:
        filter_rating = float(filters[1])
    subset = []  # Create a blank subset of option to populate
    # Cycle through the restaurants and only keep the ones within the filter ranges
    for restaurant in set:
        if "price_level" in restaurant:
            rest_price = restaurant["price_level"]
        else:
            rest_price = 0
        if "rating" in restaurant:
            rest_rating = float(restaurant["rating"])
        else:
            rest_rating = 5.0
        if rest_price <= len(filter_price) and rest_rating >= filter_rating:
            subset.append(restaurant)
    return subset

def write_location(location):
    """
    Write location data to text files for the Map to read
    :param location: dictionary containing lat and lng keys and values
    :return: None
    """
    # Define output files
    lat_filename = '../daviesa2_react/src/lat.txt'
    lng_filename = '../daviesa2_react/src/lng.txt'
    # Write the latitude file
    file = open(lat_filename, 'w')
    file.write(str(location["lat"]))
    file.close()
    # Write the longitude file
    file = open(lng_filename, 'w')
    file.write(str(location["lng"]))
    file.close()
    return

def run_random_subset_microservice(input_file=""):
    """
    Launches the random subset microservice. It will run until it is terminated by the user or receives a kill command
    from the input file.
    :param input_file: (string) defines the input file that the service will read from. If no input is provided, it
                            will assume the input file to be inputs.txt.
    :param output_file: (string) defines the output file that the service will write to. If no input is provided, it
                            will write to the input file.
    :return: N/A. Writes to a text file in json format

    Text file inputs:
    "set" - required - array or string
    "number" - optional  - integer
    "dwell" - optional - float
    "kill" - optional - any
    """
    # If an input file is defined, use that. Else, default to an arbitrary text file.
    if input_file != "" and type(input_file) == str:
        input_filename = input_file
    else:
        input_filename = "microservice_output.txt"
    output_filename = '../daviesa2_react/src/results.txt'
    execute = True
    prior_status = ''  # Initialize variable to document the prior file value
    # While the execute flag is true
    while execute:
        # Check if the input exists and try opening it. Else, create a temp dictionary.
        if exists(input_filename):
            file = open(input_filename, "r")
            try:
                status = json.load(file)
            except:
                status = dict()
                pass
            file.close()
        else:
            print("No input file exists. Check directory for inputs.txt.")
            status = dict()
        # If the file content isn't a dictionary (JSON), then print an error.
        if type(dict()) != type(status):
            print("Input is not in JSON format. Verify input format in inputs.txt.")
            status = dict()
        outputs = dict()  # Initialize a dictionary to store outputs in
        # If the current and prior contents match, don't do anything. Else, generate outputs.
        if compare_JSONs(status, prior_status):
            print("File is unchanged. No actions taken.")
        elif "output" in status:
            subset = filter_results(status["output"])
            # If nothing matches the filters, try again
            if len(subset) == 0:
                pick = dict()
                pick["name"] = "Nothing is showing up. Try again."
                pick["geometry"] = dict()
                pick["geometry"]["location"] = dict()
                pick["geometry"]["location"]["lat"] = 47.608013
                pick["geometry"]["location"]["lng"] = -122.335167
            # Else, utilize the pick
            else:
                pick = random.choices(subset, weights=[len(subset)] * len(subset),
                                      k=1)  # Define the random outputs
                pick = pick[0]
            line = pick["name"]
            file = open(output_filename, 'w')
            file.write(line)
            file.close()
            geometry = pick["geometry"]
            write_location(geometry["location"])
            prior_status = deepcopy(status)
            # If a dwell is commanded, pause for the input-provided time
            if "dwell" in status:
                dt = status["dwell"]
                print(f"Dwelling for {dt} seconds...")
                time.sleep(dt)
        # If a kill/stop is requested, set the execute flag to false
        if "kill" in status:
            execute = False

if __name__ == "__main__":  # If this isn't being called by another script
    run_random_subset_microservice()
