// Get the mongoose object
import mongoose from 'mongoose';
import fs from 'fs';
import { writeFile, readFile } from 'fs/promises';
import { Buffer } from 'buffer';

// Prepare to the database exercises_db in the MongoDB server running locally on port 27017
mongoose.connect(
    "mongodb://localhost:27017/filters_db",
    { useNewUrlParser: true, useUnifiedTopology: true }
);

// Connect to to the database
const db = mongoose.connection;
// The open event is called when the database connection successfully opens
db.once("open", () => {
    console.log("Successfully connected to MongoDB using Mongoose!");
});

/*
Create a function to wait for microservices to process requests
*/
function resolveAfter2Seconds(x) {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve(x);
      }, 600);
    });
}

/**
 * Define the schema for the filter
 */
const filterSchema = mongoose.Schema({
    location: { type: String, required: true },
    price: { type: String, required: false },
    rating: { type: String, required: false},
    range: { type: String, required: false},
    result: { type: String, required: true},
    lat: { type: Number, required: true},
    lng: { type: Number, required: true}
});

/**
 * Compile the model from the schema. This must be done after defining the schema.
 */
const Filter = mongoose.model("Filters", filterSchema);

/**
 * Create an filter, write files, and return outputs via response
 * @param {String} location
 * @param {String} price
 * @param {String} rating
 * @param {String} range
 * @param {String} result
 * @param {Number} lat
 * @param {Number} lng
 * @returns A promise. Resolves to JSON object for the document created by calling save
 */
const createFilter = async (location, price, rating, range) => {
    // Define the filters and write them to their files
    const outputString = location + ", " + range*1600;
    const optionalFilters = price + ", " + rating;
    const promise = await resolveAfter2Seconds(writeFile('microservice.txt', outputString));
    const optionalPromise = await resolveAfter2Seconds(writeFile('additional_filters.txt', optionalFilters))
    // Read the output files to define the key values of name and location
    var result = await resolveAfter2Seconds(readFile('../daviesa2_react/src/results.txt', 'utf-8', function(err, content) {
        console.log(content)}));
    var lat = await resolveAfter2Seconds(readFile('../daviesa2_react/src/lat.txt', 'utf-8', function(err, content) {
        console.log(content)}));
    var lng = await resolveAfter2Seconds(readFile('../daviesa2_react/src/lng.txt', 'utf-8', function(err, content) {
        console.log(content)}));
    // Call the constructor to create an instance of the model class Filter and return the JSON
    const filter = new Filter({ location: location, price: price, rating: rating, range: range, result: result, lat: lat, lng: lng });
    const clear = await Filter.deleteOne({});
    return filter;
}

export { createFilter };