import * as exercises from './exercises_model.mjs';
import express from 'express';

const PORT = 3000;

const app = express();

app.use(express.json());

/*
 * Create a new filter with the parameters provided in body
 */
app.post('/exercises', (req, res) => {
    console.log(req.body)
    // Create the filter using the body of the request
    exercises.createFilter(req.body.location, req.body.price, req.body.rating, req.body.range)
        // If a 201 is received, return the filters and results
        .then(exercise => {
            res.status(201).json(exercise);
        })
        // Else, notify there has been an error (400)
        .catch(error => {
            console.error(error);
            res.status(400).json({Error: 'Request failed'});
        })
});

/* Display that the database is active */
app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}...`);
});